// Worker线程文件
// 计算工作
this.onmessage = function (e) {
  //3.接收主线程发送的消息并且计算
  //参数e代表的是MessageEvent(消息事件)
  //在MessageEvent对象中存在data属性,该属性的值为主线程postMessage()
  //方法中的值
  let data = e.data;
  let sum = 0;
  for (let n = 0; n <= data; n++) {
    sum += n;
  }
  //4.worker线程向主线程发送消息
  this.postMessage(sum);
}