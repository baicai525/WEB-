// Worker线程文件
// 计算工作
this.onmessage = function(e){
  //参数e代表的是MessageEvent(消息事件)
  console.log(e);
  //postMessage
}