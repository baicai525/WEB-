// 创建HTTP服务器
const app = require('http').createServer();
// 创建Socket服务器
const server = require('socket.io')(app);

//服务器侦听客户端连接到服务器的事件
//client代表的时每一个连接到服务器的客户端
server.on('connection', (client) => {
  //客户登录的事件
  client.on('user logined', (data) => {
    server.emit('welcome new user',data);
  })
  // 客户发送消息的事件
  // 侦听客户端的事件,当然侦听到指定的事件后,执行相关的回调函数
  // data参数代表的是客户端提交给服务器的信息
  client.on('send a message', (data) => {
    //服务器向所有的客户端广播事件
    server.emit('boast a message', data);
  });
});

// 启动HTTP服务器
app.listen(5000);