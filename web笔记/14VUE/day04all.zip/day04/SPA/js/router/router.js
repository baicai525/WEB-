//路由字典: 包含多对儿相对路径与组件对象间对应关系
var routes=[
  {path:"/", component:Index},
  // {path:"/details", component:Details},
  {path:"/details/:lid", component:Details, props:true},
  {path:"*", component:NotFound}
  //强调: component后的组件对象名必须和组件.js文件中的组件对象名一致！
];
//路由器对象
var router=new VueRouter({ 
  routes 
})