var Index={
  template:`<div>
    <my-header></my-header>
    <h3 style="color:red">这里是首页</h3>
    <ul>
      <li><button @click="goto">查看5号商品的详情</button></li>
      <li><router-link to="/details/13">查看13商品的详情</router-link></li>
    </ul>
  </div>`,
  methods:{
    goto(){
      this.$router.push("/details/5")
    }
  }
}