var Details={
  template:`<div>
    <my-header></my-header>
    <h3 style="color:green">这里是详情页</h3>
    <ul>
      <li>商品编号: {{product.lid}}</li>
      <li>商品名称: {{product.title}}</li>
    </ul>
  </div>`,
  data(){
    return {
      product:{}
    }
  },
  //因为router.js中写了props:true
  props:["lid"],//使用变量名lid获得地址中/后传来的参数值
  mounted(){
    axios.get("http://xzserver.applinzi.com/details",{
      params:{ lid: this.lid }
    }).then(result=>{
      //console.log(result.data);
      this.product=result.data.product;
    })
  }
}