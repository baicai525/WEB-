//坑: 在起组件名时，不能使用HTML标准标签名
var MyHeader={
  template:`<div>
    <h3 style="color:blue">这里是页头</h3>
    <ul>
      <li><router-link to="/">首页</router-link></li>
      <li><router-link to="/details">详情页(废弃)</router-link></li>
    </ul>
    <hr/>
  </div>`
}