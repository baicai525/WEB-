//创建todo-list组件
var todoList={
  template:`<ul>
    <li><todo-item></todo-item></li>
    <li><todo-item></todo-item></li>
    <li><todo-item></todo-item></li>
  </ul>`,
  //todoItem是todoList的子组件
  components:{ todoItem }
}