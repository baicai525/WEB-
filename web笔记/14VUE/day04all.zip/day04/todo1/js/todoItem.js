//创建todo-item组件
var todoItem={
  template:`<div>
    1. 吃饭 <a href="javascript:;">×</a>
  </div>`
}