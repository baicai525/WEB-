//创建todo-add组件
var todoAdd={
  template:`<div>
    <input><button>+</button>
  </div>`
}