//创建todo-list组件
var todoList={
  template:`<ul>
    <li v-for="(t,i) of tasks" :key="i">
      <todo-item :t="t" :i="i"></todo-item>
    </li>
  </ul>`,
  props:["tasks"],
  //todoItem是todoList的子组件
  components:{ todoItem }
}