//创建todo组件
Vue.component("todo",{
  template:`<div>
    <h3>待办事项列表</h3>
    <todo-add></todo-add>
    <todo-list :tasks="tasks"></todo-list>
  </div>`,
  data(){
    return {
      tasks:[ "吃饭", "睡觉", "打亮亮"]
    }
  },
  //todoAdd和todoList是todo的子组件
  components:{ todoAdd, todoList }
})