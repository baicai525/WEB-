//创建todo-item组件
var todoItem={
  template:`<div>
    {{i+1}}. {{t}} <a href="javascript:;">×</a>
  </div>`,
  props:["t","i"]
}