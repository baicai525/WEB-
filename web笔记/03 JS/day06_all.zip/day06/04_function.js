//全局污染：全局变量出现对其它的变量造成了影响
//解决：将全局变量转为局部变量
//匿名函数自调用
//轮播图1
(function(){
  var num=1;
  console.log(num);
})();

//轮播图2
(function(){
  //作用域
  var num=3;
})();

//轮播图3
(function(user){
  var num=4;
  console.log(user);
})('root');


