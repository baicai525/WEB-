//使用递归计算1~n之间所有整数的和
function getSum(n){
  //结束条件：当n为1的时候，返回1
  if(n===1){
    return 1;
  }
  //前n个数的和，等价于n + 前n-1项的和
  return n+getSum(n-1);
}
var r=getSum(100);
//console.log(r);
//5+getSum(4)
//5+4+getSum(3)
//5+4+3+getSum(2)
//5+4+3+2+getSum(1)
//当n为1的时候，直接返回1
//5+4+3+2+1

//5+4+3+2+1
//5+getSum(4)
//   
//4+3+2+1
//4+getSum(3)
//
//3+2+1
//3+getSum(2)
//
//2+1
//2+getSum(1)


//练习：使用递归计算斐波那契数列第n项的值（20,40,50,70）
function fib(n){
  //结束条件：当n为1或者n为2的时候，返回1
  if(n===1 || n===2){
    return 1;
  }
  //第n的值，等价于第n-1项+第n-2项
  return fib(n-1) + fib(n-2);
}
console.log( fib(50) );
/*
fib(4)+fib(3)
fib(3)+fib(2)+fib(2)+fib(1)
fib(2)+fib(1)+fib(2)+fib(2)+fib(1)
1 + 1 + 1 + 1 + 1
*/
//递归属于CPU密集型算法
//JS 单线程








