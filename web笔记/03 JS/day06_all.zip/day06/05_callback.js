function ran(madai){
  console.log('第一棒开始跑...');
  console.log('第一棒结束，准备交接棒');
  //madai=dong;
  //madai=xin;
  //madai=function(){}
  //madai() // dong() xin()  (function(){  })()
  //函数dong已经放入到了形参madai中，如果调用dong，只需要调用madai
  madai();
}
function dong(){
  console.log('接收到第一棒，开始跑第二棒');
  console.log('到达终点');
}
//把dong函数以实参的形式传递，在这个位置 dong就叫做回调函数
//ran(dong);
//创建一个函数xin负责跑第二棒，由ran抱着xin来跑
function xin(){
  console.log('xin开始跑第二棒');
  console.log('到达终点');
}
ran(xin);
//ran调用的时候，抱着陌生人(匿名函数)
ran( function(){
  console.log('陌生人跑远了');
} );
