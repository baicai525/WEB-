//内置构造函数创建对象
var emp=new Object();
//需要单独添加每一个属性
emp.eid=1;
emp.ename='然哥';
emp['sex']='男';
//console.log(emp,typeof emp);
//练习：创建一个商品对象，包含有商品的编号，标题，价格，是否在售
var laptop=new Object();
laptop.lid=1;
laptop.title='小米Air';
laptop.price=3199;
laptop.isOnsale='是';
//console.log(laptop);

//遍历属性
//for in
for(var k in laptop){
  //k代表每一个属性名
  //laptop 要遍历的对象
  console.log(k,laptop[k]);
}


