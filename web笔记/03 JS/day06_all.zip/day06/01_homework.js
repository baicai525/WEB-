/*
//变量交换
var a=1;
var b=2;
var c=a;
a=b;
b=c;
console.log(a,b);
*/

//创建函数，计算斐波那契数列第n项的值
function fib(n){
  //第1项和第2项的值都是1
  var n1=1,n2=1;
  //如果要求第n项的，只需要让n1和n2不断的往后挪动，挪动结束后，n2的值就是所求项的值
  //每次挪动从3开始，表示循环从3开始
  for(var i=3;i<=n;i++){
    //挪动的原理：n1的值是上一次n2的值，n2的值是上一次n1和n2相加的和
	var c=n1;
    n1=n2;
	n2=c+n2;
  }
  //挪动结束后，n2的值就是所求项的值
  return n2;
}
var r=fib(2);
console.log(r);




