//字面量(直接量)创建对象
var phone={
  color:'黑色',
  size:10.8,
  'caizhi':'振金',
  'made-in':'瓦坎达'
}
//console.log(phone);
//练习：创建一个汽车对象，包含有汽车的品牌，颜色，长度，宽度，产地
var car={
  brand:'大黄蜂',
  color:'黄色',
  width:1.8,
  length:5.2,
  'made-in':'赛博坦'
}
//console.log(car);
//访问属性
//console.log( car.brand, car.color, car.age );
//修改
car.color='绿色';
car.age=5;
//访问特殊
car['made-in']='地球';
car['length']=12;
//console.log(car);

//练习：创建一本图书的对象，包含有图书的编号，标题，价格，作者；修改图书的价格，添加图书的出版社，打印出图书的作者；打印整个对象
var book={
  bid:10086,
  title:'煎饼的做法',
  author:'尼古拉斯.然',
  price:199
}
book.price=399;
book['publish']='瓦坎达出版社';
console.log( book.author );
console.log(book);


