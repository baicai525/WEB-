/*
var str='2';
var n=Number(str);
console.log(n);
//检测str转数值后是否为NaN
console.log( isNaN(str) );


//console.log(0/2, -2/0);
//检测一个值是否为有限值
//无限值  Infinity
var num=2/0;
console.log(num);
console.log( isFinite(num) );
*/

console.log('1+2');
//执行字符串中的表达式
console.log( eval('1+2') );

console.log( 'parseInt(3.14)' );
console.log( eval('parseInt(3.14)') );
