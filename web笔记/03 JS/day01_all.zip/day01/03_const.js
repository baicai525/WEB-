//声明常量
const pi=3.14;
//不允许重新赋值
//pi=3.1415;
console.log(pi);