//声明变量
var x=1;
var y='ran';
//console.log(x,y);
//练习：声明多个变量，分别保存一个员工的编号，姓名，性别，工资；最后打印出来
var eid=5;
var ename='然哥';
var sex='女';
var salary=38000;
//console.log(eid,ename,sex,salary);

//变量的命名规则
var a1=1;
var _b_2=2;
var $c$3=3;
var 姓名='然';
//语义

//console.log(姓名);

//声明变量未赋值
var n;//undefined 
//给变量重新赋值
n=1;
n='hello';
//console.log(n);

//练习：声明变量分别保存语文、数学和总成绩，其中总成绩暂时未赋值，然后把语文和数学相加的和赋给总成绩，最后打印3个变量。
var chinese=70;
var math=80;
var total;
total=chinese+math;
//console.log(chinese,math,total);

//一次声明多个变量
var a=1,b=2,c;
/*
等价于
var a=1;
var b=2;
var c;
*/
//console.log(a,b,c);

///练习：声明多个变量分别保存多组商品的单价和数量，最后计算出总价并打印出来。
var price1=20,num1=3,price2=14.8,num2=10;
console.log(price1*num1+price2*num2);

