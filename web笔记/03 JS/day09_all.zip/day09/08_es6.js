function add(a=0,b=0,c=0){
  console.log(a+b+c);
}
add(2,5,7);
add(48,91);
add(63);