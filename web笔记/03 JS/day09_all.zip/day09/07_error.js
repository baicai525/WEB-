console.log(1);
//语法错误
//var a=1；
var a1=2;
//引用错误
//console.log(a2);
//parseint(3.14);

//var arr=['a','b','c']
//类型错误
//console.log( arr.tostring() );
//范围错误
//var arr=new Array(-3);
//自定义错误
//throw '请提供年龄';


//错误处理
var age=25;
//尝试执行，可能会有错误
try{
  //如果年龄不在18~60之间，则抛出错误
  if(age<18 || age>60){
    throw '非法的年龄';
  }
}catch(err){
  //只有try中出现错误以后才会执行
  //如果产生错误会将错误保存到err
  console.log(err);
  //处理错误
  age=60;
}

console.log(age);


console.log(2);