var a=true;
var b=new Boolean(1);
//false: 0  NaN  undefined  null  ''
//[]  {}
var c=Boolean({});
//console.log(b,typeof b);
console.log(c);