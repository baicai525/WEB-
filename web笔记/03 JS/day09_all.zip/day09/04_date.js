/*
//本地字符串
var d=new Date();
console.log( d.toLocaleString() );
console.log( d.toLocaleDateString() );
console.log( d.toLocaleTimeString() );


//设置
var d=new Date('2020/8/17 15:15:0');
d.setHours(16);
d.setMinutes(0);
d.setFullYear(2021);
d.setMonth(12);//0~11 对应1月~12月
//距离计算机元年毫秒数
d.setTime(1479800000000);
//不能设置星期
//d.setDay(3);
console.log( d.toLocaleString() );
*/

//练习：创建对象保存一个员工的入职时间2020/5/18，假设合同期为3年，计算出合同到期时间。到期年份在当前的基础之上加3，最后打印出入职时间和到期时间两个对象的本地字符串格式。
//入职时间
var d1=new Date('2020/5/18');
//复制一份入职时间，作为到期时间
//拷贝d1对象
var d2=new Date(d1);
//3年后：年份在当前基础之上加3
//自动获取年份，然后加3；把结果作为到期的年份
d2.setFullYear( d2.getFullYear()+3 );
//到期前一个月要续签合同，打印出续签时间。
//拷贝一个到期时间，然后提前1个月
var d3=new Date(d2);
//提前1个月
d3.setMonth( d3.getMonth()-1 );

console.log( d1.toLocaleString() );
console.log( d2.toLocaleString() );
console.log( d3.toLocaleString() );