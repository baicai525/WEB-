/*
var d1=new Date('2020/8/17 10:45:30');
var d2=new Date(2020,7,17,10,45,30);//月份 0~11
var d3=new Date();//当前所在操作系统时间
//存储距离计算机元年(1970/1/1 0:0:0)的毫秒数
//2020/1/1
//50*365*24*60*60*1000
var d4=new Date(50*365*24*60*60*1000);

console.log(d4);


var d=new Date();
//console.log( d.getFullYear() );
//console.log( d.getMonth()+1, d.getDate() );
//console.log( d.getHours() );
//console.log( d.getMilliseconds() );//毫秒
//console.log( d.getDay() );//0~6
//获取当前对象距离计算机元年毫秒数
console.log( d.getTime() );

//练习：假设从数据库中获取到了存储的日期时间1537587120000，打印出以下格式
//xxxx年xx月xx日  xx:xx:xx  星期x
var d=new Date(1537587120000);
var year=d.getFullYear();
var month=d.getMonth()+1;
var date=d.getDate();
var hour=d.getHours();
var minute=d.getMinutes();
var second=d.getSeconds();
if(second<10){
  //数字前拼接0
  second='0'+second;
}
var day=d.getDay();//0~6
var arr=['日','一','二','三','四','五','六'];
console.log(year+'年'+month+'月'+date+'日 '+hour+':'+minute+':'+second+' 星期'+arr[day]);
*/

//当前时间距离2020年国庆节还有x天x小时x分x秒
//当前时间对象
var d1=new Date();
//2020年国庆节对象
var d2=new Date('2020/10/1');
//计算两者相差的毫秒数
var d=d2.getTime()-d1.getTime();
//console.log(d);
//两个对象相减得到的是相差的毫秒数
//console.log(d2-d1);
//将相差的值由毫秒换算为秒，向下取整
d=parseInt( d/1000 );
//计算两者相差的天数，把相差的值换算为天 = 总的秒数/一天的秒数,向下取整
var day=parseInt( d/(24*60*60) );
console.log(day);
//计算两者相差的小时，总的秒数-44天的秒数，把剩余的秒数换算为小时
//去除93中所有的10
//93-9*10=3
//93%10=3
//总的秒数%一天的秒数取余，可以去除所有的天数，把剩余的秒数换算为小时
var hour=d%(24*60*60);
//换算为小时，向下取整
hour=parseInt( hour/(60*60) );
console.log(hour);
//计算相差的分钟，总的秒数-44天的秒数-9小时的秒数，剩余的秒数换算为分钟
//总的秒数%一小时的秒数取余
var minute=d%(60*60);
//换算为分钟，向下取整
minute=parseInt( minute/60 );
console.log(minute);
//计算相差的秒钟，去除相差的分钟
//总的秒数-44天的秒数-9小时的秒数-16分钟秒数
var second=d%60;
console.log(second);