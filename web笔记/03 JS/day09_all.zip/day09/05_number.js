/*
var n1=1;//字面量
var n2=new Number(true);//构造函数
var n3=Number(true);
//console.log(n1,typeof n1);
//console.log(n2,typeof n2);
//console.log(n3,typeof n3);
console.log(n2+3, n3+3);
*/

var n=2*5*3.14;
var n2=0.1+0.2;
//console.log(n.toFixed(2),n2.toFixed(1));

var price=5000;
console.log( price.toFixed(2) );
