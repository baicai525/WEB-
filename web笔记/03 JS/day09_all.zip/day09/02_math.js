/*
//准备数组
var arr=['周亮','吴文豪','颜涛','魏晓慧','giao哥','陈婕','段伟','石卓然','彭冠祖','陈锡阳','刘方宇','刘柯','马杰','马冬梅'];
//0~9
//随机产生0~9整数，然后作为下标来找对应的元素
//0~1 * 10  0~9.x   向下取整  0~9
//var n=parseInt( Math.random()*10 );
//console.log(n, arr[n]);
//准备一个空数组，用于保存随机元素
var arr2=[];
//使用循环，随机4个
for(var i=0;i<4;i++){
  //0~1 * 12  0~11.x  向下取整  0~11
  var n=parseInt( Math.random()*arr.length );
  //console.log(n, arr[n]);
  //把产生的随机元素保存下来
  arr2.push( arr[n] );
}
console.log(arr2);

*/


//向下取整
//console.log( Math.floor(-3.67) );
//去除小数点部分取整
//console.log( parseInt(-3.67) );//-3
//向上取整
//console.log( Math.ceil(3.67) );
//四舍五入取整
//console.log( Math.round(3.47) );

//找最大
//console.log( Math.max(23,9,78,6,45) );
//找最小
//console.log( Math.min(23,9,78,6,45) );

//次方（次幂）
//console.log( Math.pow(5,2) );

//圆周率
//console.log( Math.PI );

//绝对值
console.log( Math.abs(3-10) );

