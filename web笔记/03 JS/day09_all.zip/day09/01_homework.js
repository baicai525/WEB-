/*
//1.将一句英文中所有单词首字母大写，其余字母小写
var str='whAT aRe yOU doING';
//按照空格切割为数组，得到每个单词
var arr=str.split(' ');
//遍历数组
for(var i=0;i<arr.length;i++){
  //arr[i]  每个单词
  //截取首字母转大写，并保存下来
  var f=arr[i].substr(0,1).toUpperCase();
  //截取第二个到最后所有的字母转小写，并保存
  var o=arr[i].substr(1).toLowerCase();
  //拼接以上两部分组成新单词，替换之前的单词
  //console.log(f+o);
  arr[i]=f+o;
}

//所有字符串下的API都不会对原来的字符串造成影响
//把数组转回成字符串，单词之间按照空格分隔
console.log(arr.join(' '));
*/

//2.获取1~16之间的随机整数
//0~1 * 16  0~15.x  向下取整  0~15  + 1   1~16
var n=parseInt( Math.random()*16 ) + 1;
console.log(n);

