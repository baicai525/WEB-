/*
//JS程序执行前，会将var声明的变量提升到所在作用域的最前边，赋值不提升。
//var a
console.log(a);//undefined
var a=1;

function fn(){
  //var b
  console.log(b);//undefined
  var b=5;//b=5
  console.log(b);//5
}
fn();

//全局变量c
var c=3;
function fun(){
  //局部变量c
  //var c
  //访问变量c，首先到当前作用域下寻找
  console.log(c);
  var c=6;
}
fun();


function foo(n){
  //参数属于是局部变量，无法被外部访问
}
foo(2);
//console.log(n);
*/
//全局变量m
var m=5;
function bar(m){
  //m是参数，局部变量
  //var m=6;
  //修改的是参数m，对全局没有任何影响
  m=m+7;
}
bar(6);
//访问全局m
console.log(m);