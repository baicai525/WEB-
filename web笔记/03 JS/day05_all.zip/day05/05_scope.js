/*
//全局作用域下的变量称为全局变量
var a='北京城管';
function shi(){
  //函数作用域
  //局部变量
  var b='石景山城管';
  //在函数中访问全局变量
  console.log(a);
}
shi();
//在全局访问局部变量
console.log(b);

function hai(){
  //函数作用域
  //局部变量
  var c='海淀城管';
}


//全局变量
var n1=3;
function fn(){
  //访问全局变量，重新赋值为5
  n1=5;
  //函数中不加var声明的变量是全局变量
  n2=8;
}
fn();
//console.log(n1);
console.log(n2);
*/


function fun(){
  var m1=m2=m3=5;
  //m3=5  //全局
  //m2=m3 //全局
  //var m1=m2; //局部变量
}
fun();
console.log(m3);//5
console.log(m2);//5
console.log(m1);//报错

