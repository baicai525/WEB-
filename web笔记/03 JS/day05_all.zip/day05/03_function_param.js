//计算任意两个数字相加的和
function add(a,b){//形参，用于接收数据
  console.log(a,b);
  //console.log(a+b);
}
//调用
//实参会赋值给形参
//add(3,5);//实参，实际传递的数据
//add(2,7);
//add(4,9,13);//实参数量可以多于形参数量
//add(5);//实参数量可以少于形参数量
//add();


//练习：创建函数，封装计算1~任意数字之间所有整数的和，打印出来，调用多次
function getSum(n){
  //计算1~n之间所有整数的和
  for(var i=1,sum=0;i<=n;i++){
    sum+=i;
  }
  console.log(sum);
}
//getSum(1000);
//getSum(100);
//getSum(500);
//练习：创建函数，计算任意两个年份之间的闰年个数，调用多次
function getCount(n1,n2){
  //循环产生n1~n2之间所有的年份
  for(var i=n1,count=0;i<=n2;i++){
    //如果是闰年，则count加1
	if(i%4===0 && i%100!==0 || i%400===0){
	  count++;
	}
  }
  console.log(count);
}
getCount(2000,2100);



