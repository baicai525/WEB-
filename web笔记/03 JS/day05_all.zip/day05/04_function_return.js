//计算任意两个数字相加的和
function add(a,b){
  //打印仅仅是将结果显示到控制台，无法将结果返回
  //console.log(a+b);
  //返回值：函数调用后所得到的结果
  //return '大腰子+30羊肉串';
  //return a+b;
  return;
  //return执行后，结束函数的执行
  console.log('结束');
}
//将函数调用后的结果保存
//var r=add(2,4);
//console.log('两个数字相加的结果:',r);

//练习：创建函数getMax1，传递任意两个数字，返回最大值
function getMax1(a,b){
  /*
  if(a>b){
    return a;
  }else{
    return b;
  }
  */
  return a>b ? a : b;
}
var r=getMax1(1,3);
//console.log(r);

//练习：创建函数getMax2，传递任意三个数字，返回最大值
function getMax2(a,b,c){
  /*
  if(a>b && a>c){
    return a;
  }else if(b>c){
    return b;
  }else{
    return c;
  }
  */
  var max=a>b ? a : b;
  return max>c ? max : c;
}
var r=getMax2(14,8,5);
//console.log(r);

//练习：创建函数getStatus，传递订单的状态码，返回对应的汉字状态。
//1-等待付款  2-等待发货  3-运输中  4-已签收  5-已取消  其它-无法追踪的状态
function getStatus(n){
  switch(n){
    case 1:
	  return '等待付款';
	  //break;
	case 2:
	  return '等待发货';
	  //break;
	case 3:
      return '运输中';
	  //break;
	case 4:
	  return '已签收';
	  //break;
	case 5:
	  return '已取消';
	  //break;
	default:
	  return '无法追踪的状态';
  }
}
var r=getStatus(2);
//console.log(r);

//练习：创建函数isRun，传递任意一个年份，如果是闰年返回true，否则返回false
function isRun(n){
  /*
  if(n%4===0 && n%100!==0 || n%400===0){
    return true;
  }
  return false;
  */
  return n%4===0 && n%100!==0 || n%400===0;
}
var r=isRun(2020);
console.log(r);





