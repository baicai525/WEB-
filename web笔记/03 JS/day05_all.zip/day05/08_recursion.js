//声明变量记录次数
var i=0;
function say(){
  console.log('从前有座山');
  //每打印1次加1
  i++;
  //当i为3的时候
  if(i===3){
    return;
  }
  //递归
  say();
}
say();