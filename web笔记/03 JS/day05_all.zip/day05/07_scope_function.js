/*
//全局函数
function fn(){

}
var a=2;
function fn1(){
  //函数作用域
  //局部变量
  var a=1;
  //局部函数
  function fn2(){
    console.log(a);
  }
  //调用局部函数fn2
  fn2();
}
fn1();
//在全局作用域调用局部函数
//fn2();

*/

//函数提升
fun();
function fun(){
  console.log(1);
}


