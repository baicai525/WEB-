/*
console.log('卖煎饼了');
console.log('又香又脆的煎饼');
console.log('所有煎饼一律九折');
*/
//创建函数
function laba(){
  //函数体
  console.log('卖煎饼了');
  console.log('又香又脆的煎饼');
  console.log('所有煎饼一律10.5折');
}
//调用
//laba();
//laba();
//练习：创建函数，在函数体中封装计算1~100之间所有整数的和并打印，调用多次
function getSum(){
  //函数体
  for(var i=1,sum=0;i<=100;i++){
    sum+=i;
  }
  console.log(sum);
}
getSum();
getSum();
getSum();

