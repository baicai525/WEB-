/*
//打印1~10之间所有整数，不包括6
for(var i=1;i<=10;i++){ 
  if(i===6){
    //break;//结束循环
	continue;//跳过循环体，继续往后执行后续的循环
  }
  console.log(i);
}
*/
//练习：打印1~100之间所有的偶数，如果遇到奇数就跳过
//打印所有的整数
for(var i=1;i<=100;i++){
  //如果i为奇数跳过
  if(i%2===1){
    continue;
  }
  console.log(i);
}





