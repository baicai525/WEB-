/*
//循环打印1~10
var i=1;
while(true){
  //循环体
  console.log(i);
  //当i的值为10，强制结束循环
  if(i===10){
    break;
  }
  i++;
}
*/
//练习：使用死循环计算11~20之间所有整数的乘积
var i=11;
//声明变量，用于计算乘积，初始值是1
var s=1;
while(true){
  //i是11~20所有整数
  //console.log(i);
  //把所有的整数乘以到s中
  s*=i;
  //当i为20的时候，结束循环
  if(i===20){
    break;
  }
  i++;
}
console.log(s);









