//弹出两次提示框分别输入商品的单价和数量，计算出总价，假设总价满1000元打九折，当前会员卡内有余额1200，如果足以支付，警示框弹出'pay success'，否则警示框弹出'pay error'
//弹出两次提示框，输入商品的单价和数量
var price=prompt('input price');
var num=prompt('input number');
//计算总价
var total=price*num;
console.log(total);
//判断是否满1000
if(total>=1000){
  //打九折
  total*=0.9;
}
console.log(total);
//会员卡余额
var money=1200;
//如果会员卡足以支付
if(money>=total){
  alert('pay success');
}else{
  alert('pay error');
}









