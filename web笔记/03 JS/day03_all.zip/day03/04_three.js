//满18岁打印成年人，否则打印未成年人
/*
var age=11;
age>=18 ? console.log('成年人') : console.log('未成年人'); 
var r=age>=18 ? '成年人' : '未成年人';
console.log(r);
*/
//声明变量保存任意一个年份，如果是闰年，打印'闰年'，否则打印'平年'
var year=2021;
var y=year%4===0 && year%100!==0 || year%400===0 ? '闰年' : '平年';
console.log(y);







