/*
//判断一个人是否为成年人
var age=10;
if(age>=18){
  console.log('成年人');
}else{
  console.log('未成年人');
}
age>=18 ? console.log('成年人') : console.log('未成年人');

//练习：声明变量保存用户输入的用户名和密码，如果用户名是root并且密码是123456，打印登录成功，否则打印登录失败
//使用三目运算符和if-else两种方法
var uname='root';
var upass='12345';
if(uname==='root' && upass==='123456'){
  console.log('登录成功');
}else{
  console.log('登录失败');
}

var res=uname==='root' && upass==='123456' ? '登录成功' : '登录失败';
console.log(res);
*/
//练习：声明变量保存获取到的性别的值(1/0)，如果值是1打印男，否则打印女，使用if-else和三目运算符两种方法
var sex=0;
if(sex){
  console.log('男');
}else{
  console.log('女');
}

var s=sex ? '男' : '女';
console.log(s);


















