//满30减15
//订单金额
var total=22;
//判断是否满30
if(total>=30){
  //在订单金额基础上减15
  total-=15;
}
//console.log(total);
//练习：声明变量保存年龄，如果满18岁打印成年人
var age=10;
if(age>=18){
  console.log('成年人');
  console.log('可以独自旅行了');
}
//age>=18 && console.log('成年人');

//false:0 NaN '' undefined null
if(null){
  console.log('ok');
}

//练习：声明变量保存签名内容，如果签名内容为空字符，则设置为默认'这家伙很懒，什么也没留下'，打印签名内容。
var str='';
if(!str){//str===''
  str='这家伙很懒，什么也没留下';
}
console.log(str);
