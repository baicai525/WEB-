//弹出警示框
//alert('WEB');
//弹出提示框
//var str=prompt('input string');
//console.log(str,typeof str);

//练习：声明变量分别保存用户两次输入的值，计算两个值相加的和，将和以警示框的形式弹出。
var n1=prompt('input num1');
var n2=prompt('input num2');

alert(Number(n1)+Number(n2));






