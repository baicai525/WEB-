var n='2';
switch(n){
  case 1:
    console.log('非洲');
    break;
  case 2:
	console.log('印度');
    break;
  case 3:
	console.log('日本');
    break;
  default:
	console.log('家里蹲');
}

//练习：声明变量保存一个城市的名称，根据城市的名称打印对应的特色美食
var city='重庆';
switch(city){
  case '重庆':
  case '成都':
    console.log('火锅');
    break;
  case '广州':
	console.log('早茶');
    break;
  case '北京':
	console.log('烤鸭');
    break;
  case '长沙':
	console.log('臭豆腐');
    break;
  default:
	console.log('沙县小吃');
}

//提示：让成绩除以10，然后取整
//使用switch-case
////90~100    优秀   9.x  10   9 10
//80~90以下   良好   8.x       8
//70~80以下   中等   7.x       7
//60~70以下   及格   6.x       6
//60以下      不及格
var score=85;
switch( parseInt(score/10) ){
  case 10:
  case 9:
	console.log('优秀');
    break;
  case 8:
	console.log('良好');
    break;
  case 7:
	console.log('中等');
    break;
  case 6:
	console.log('及格');
    break;
  default:
	console.log('不及格');
}



