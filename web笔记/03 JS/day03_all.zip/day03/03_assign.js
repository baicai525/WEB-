var a=1;
//自增，在原来基础之上加1
//a++;
//a=a+1;
//等价于以下
a+=3;
//console.log(a);

//练习：声明变量保存商品的价格，给该商品打八折后，打印价格
var price=100;
price*=0.8;
console.log(price);