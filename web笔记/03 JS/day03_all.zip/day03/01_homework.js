//声明变量保存任意一个年份，使用短路逻辑，如果是闰年打印'闰年'
var year=2000;
console.log( year%4===0 && year%100!==0 || year%400===0 );

(year%4===0 && year%100!==0 || year%400===0) && console.log('闰年');