//比较值是否相同
//console.log(2=='2');//true
//首先比较类型，如果类型相同再去比较值
//console.log(2==='2');
//console.log(2===2);

/*
console.log(1==true);//true隐式转换为数值1
console.log(1===true);//先比较类型
console.log(2!='3');//比较值
console.log(2!=='3');//先比较类型
*/

//console.log(3>'10');//'10'隐式转换为数值
//比较的是Unicode码
//console.log('3'>'10');
//console.log( '3'.charCodeAt(), '1'.charCodeAt() );
 
//'10a'隐式转换为数值  NaN
console.log(3>'10a');//false
console.log(3<'10a');//false
console.log(3=='10a');//false
console.log(NaN==NaN);//false
 
   
   

  
