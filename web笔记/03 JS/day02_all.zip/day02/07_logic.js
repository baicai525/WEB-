/*
//查看一个人的工资是否在5000~8000之间
var salary=3000;
//console.log( salary>=5000 && salary<=8000 );
//比较前两个的结果，得到布尔型，再和第3个比较
//console.log( 5000<=salary<=8000 );
//练习：声明变量保存用户输入的用户名和密码，如果用户名是root，并且密码是123456，则打印结果true，否则false
var uname='abc';
var upass='123456';
//console.log(uname==='root' && upass==='123456');

//判断一个人的年龄是否在12岁及以下或者60岁及以上
var age=68;
//console.log(age<=12 || age>=60);
//练习：声明变量保存用户输入的值，如果输入的值为用户名root，或者为邮箱root@126.com，或者为手机1811234567，打印true，否则false
var input='root';
//console.log( input==='root' || input==='root@126.com' || input==='18112345678' );

var a=true;
var b=3<1;
console.log(!a,!b);


var  a=5;
a>10 && console.log(b);
a<6 || console.log(c);
*/
//练习：声明变量保存年龄，如果满18岁，打印成年人
var age=11;
age>=18 && console.log('成年人');




