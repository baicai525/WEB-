//1.声明变量保存圆的半径，常量保存圆周率，把面积和周长计算分别保存到变量中，最后打印结果。
var r=5;
const pi=3.14;
//周长
var length=2*pi*r;
//面积
var area=pi*r*r;
//console.log(length,area);
//2.交换两个变量的值 
var a=1;
var b=2;
//
var c=a;
a=b;
b=c;
console.log(a,b);




