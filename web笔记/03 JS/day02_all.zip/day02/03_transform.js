var n1=2+'3';//'23'
//console.log(n1,typeof n1);

var n2=2+true;//3
var n3=2+false;//2
var n4='2'+true;//'2true'
//console.log(n4,typeof n4);

/*
var a=1,b=true,c='2';
console.log(a+b+c);//'22'
console.log(b+c+a);//'true21'
console.log(c+a+b);//'21true'
*/

//假设已经从后端获取到了商品的标题和操作系统
var title='Apple Pro';
var os='MacOS';
//console.log('商品名称：'+title+' 系统：'+os);

//练习：声明变量保存一个员工的姓名和部门名称，打印出以下效果  ‘姓名：xxx  部门名称：xxx 工资：’
var ename='然哥';
var dname='后勤部';
var salary=20000;
//console.log('姓名：'+ename+'  部门名称：'+dname+' 工资：'+salary);


var m1='5'-1;//4
var m2='2'*'3';//6
var m3=10/'5';//2
var m4=true-false;//1
var m5='2a'*'3';//NaN  Not a Number
//将数据转数值的时候，没有成功的转为数值，返回NaN
//NaN和任何值执行运算结果还是NaN
var m6=1+undefined;//NaN
console.log(m6,typeof m6);
