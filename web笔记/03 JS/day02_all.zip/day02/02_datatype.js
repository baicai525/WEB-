//整型
var n1=10;
//8进制
var n2=012;
//16进制
var n3=0XA;
//console.log(n1,n2,n3);
//浮点型
var n4=314.15;
var n5=31.415e+1;
var n6=3141.5e-1;
//console.log(n4,n5,n6);
//检测数据类型
//console.log(typeof n6);

//字符串型
var str1='2';
var str2='str1';
var str3='typeof';
//console.log(str3,typeof str3);
//查看任意一个字符的Unicode码
//console.log( '一'.charCodeAt() );

//布尔型
var b1=3>1;
var b2=3<1;
var b3=true;
//console.log(b3,typeof b3);

//未定义型
var ename;
//console.log(ename,typeof ename);

//空
var p=null;
console.log(p,typeof p);