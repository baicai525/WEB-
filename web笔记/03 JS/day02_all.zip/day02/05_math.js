//取余
//console.log(5%2);
//console.log(-5%2);
//console.log(2%5);

//自增，在原来基础之上加1
/*
var n1=5;
//n1++;
++n1;
console.log(n1);
*/
/*
var n2=3;
//先把n2当前的值赋给n3，然后n2再执行自增
var n3=n2++;
console.log(n2,n3);

var n4=7;
//先让n4执行自增，然后再把结果赋给n5
var n5=++n4;
console.log(n4,n5);


//
var a=10;
//把a当前的值赋给b，b为10，然后a执行自减，a为9
var b=a--;
//先让a的值执行自减，a为8，然后把当前a的值赋给c，c为8
var c=--a;
console.log(b+c);//10+8
console.log(a,b,c);


var a=10;
console.log(a-- + --a);
*/

var b='3';
//隐式转换为数值
b++;
console.log(b,typeof b);
//+'5'  正数，隐式转换
console.log(+'5'+ -3);
