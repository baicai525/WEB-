//隐式转换自动调用了函数 Number()
//var n1=Number('2a');
//console.log(n1*3);
var n2=Number('2');//2
var n3=Number(true);//1
var n4=Number(undefined);//NaN
var n5=Number(null);//0
//console.log(n5);

//强制转为整型
var p1=parseInt(3.94);//3
var p2=parseInt('5.18');//5
var p3=parseInt('6.7a');//6
var p4=parseInt('a6.7');//NaN
var p5=parseInt(true);
var p6=parseInt(undefined);
var p7=parseInt(null);
//console.log(p5,p6,p7);

//强制转为浮点型
var f1=parseFloat('3.14a');
var f2=parseFloat('3a');
var f3=parseFloat('a3.14');//NaN
//console.log(f3);

//数值和布尔型转字符串
var n=10;
var s1=n.toString(2);//设置进制
console.log(s1,typeof s1);

