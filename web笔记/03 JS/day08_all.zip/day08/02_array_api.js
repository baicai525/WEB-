/*
var arr=['a','b','c','d'];
//翻转
console.log( arr.reverse() );
console.log(arr);


//数组排序,默认按照Unicode码从小到大
var arr=[23,9,78,6,45];
//返回值
console.log( arr.sort( function(a,b){
  //return a-b; //数字的从小到大排序
  return b-a;
} ) );
//查看原数组是否会变
console.log(arr);


var arr1=['李坤','李京宇','然哥'];
var arr2=['周亮','周裕龙'];
var arr3=['颜涛','吴文豪','唐亮'];
//拼接数组
console.log( arr1.concat(arr2,arr3) );
console.log(arr1);


//截取数组元素
var arr=['李坤','李京宇','然哥','周亮','周裕龙','颜涛','吴文豪','唐亮'];
//
//console.log( arr.slice(1) );
//console.log( arr.slice(1,3) );
console.log( arr.slice(-4,-1) );
console.log( arr );

//练习：创建数组，包含a~g，每个字母是一个元素，分别截取出cd，f，最后拼接成一个新数组。 ['c','d','f']
var arr=['a','b','c','d','e','f','g'];
var arr1=arr.slice(2,4);
var arr2=arr.slice(-2,-1);
console.log(arr1,arr2);
console.log( arr1.concat(arr2) );


var arr=['李坤','李京宇','然哥','周亮','周裕龙','颜涛','吴文豪','唐亮'];
//删除数组元素
//arr.splice(3);
//arr.splice(3,2);
//console.log( arr.splice(-3,2) );
console.log( arr.splice(0,0,'刘波','龙昊') );
console.log(arr);

//练习：创建数组，包含a~h，每个字母是一个元素，删除b~d，替换f为m，在下标为1的位置插入z，最后打印原数组
var arr=['a','b','c','d','e','f','g','h']
console.log( arr.splice(1,3) );
console.log( arr.splice(-3,1,'m') );
console.log( arr.splice(1,0,'z') );
console.log(arr);
*/


var arr=['周裕龙','颜涛','吴文豪','唐亮'];
//在数组末尾添加元素
//console.log( arr.push('江柏锋','刘运波') );
//删除数组末尾的一个元素
//console.log( arr.pop() );
//在数组开头添加
//console.log(arr.unshift('王梦超','王胜艺'));
//删除开头的一个
console.log( arr.shift() );
console.log(arr);





