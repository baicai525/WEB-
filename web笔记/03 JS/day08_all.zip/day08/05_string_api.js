//var str='前端javascript';
//字符串长度
//console.log( str.length );
//通过下标找字符
//console.log( str.charAt(0), str[0] );
/*
//练习：声明变量保存字符串javascript，遍历字符串，打印出a出现的次数。
var str='javascript';
for(var i=0,count=0;i<str.length;i++){
  //console.log(i,str.charAt(i));
  //判断字符是否为a
  if(str.charAt(i)==='a'){
    count++;
  }
}
console.log(count);


//查找字符串中是否出现过某个字符串
//返回下标
var str='javascript';
console.log( str.indexOf('a') );//找第一个
console.log( str.lastIndexOf('a') );//找最后一个


// 练习：声明变量保存用户的邮箱，如果邮箱中不含有@打印'非法的邮箱'，否则打印'合法邮箱'
var email='ran1977@163.com'
if( email.indexOf('@')===-1 ){
  console.log('非法的邮箱');
}else{
  console.log('合法的邮箱');
}


//英文字母大小写转换
var str='JavaScript';
console.log( str.toUpperCase() );
console.log( str.toLowerCase() );


//截取字符串
var str='javascript';
console.log( str.slice(4) );
console.log( str.slice(4,7) );
console.log( str.slice(-3,-1) );


//练习：声明变量保存用户的邮箱，分别截取邮箱的用户名和域名
var email='ran19770529@qq.com';
//查找@的下标
var index=email.indexOf('@');
console.log(index);
//分别截取用户名,域名
console.log( email.slice(0,index) );
console.log( email.slice(index+1) );


//按照长度截取字符串
var str='javascript';
console.log( str.substr(4) );
console.log( str.substr(4,3) );
console.log( str.substr(-3,2) );

//练习：声明变量保存一个人的身份证号，分别截取出出生的年月日，性别（倒数第2位，奇数为男，偶数为女）
var id='110263197705292591';
var y=id.substr(6,4);
var m=id.substr(10,2);
var d=id.substr(12,2);
var s=id.substr(-2,1);
var sex= s%2===1 ? '男' : '女';
console.log(y+'年'+m+'月'+d+'日 性别'+sex);


var arr=['a','b','c'];
var str=String(arr);//'a,b,c'
//字符串转数组
//切割
console.log( str.split(',') );
//console.log(str);
*/
//slice  splice   split
// 截取    删除   切割
//然.尼古拉斯.亚历山大.山田
//使用切割字符串，获取姓氏(数组最后一位)
var str='然.尼古拉斯.亚历山大.山田';
var arr=str.split('.');
//最后一个元素下标：数组长度-1
console.log(arr);
console.log( arr[ arr.length-1 ] );
//web.2007.js.jpg
//dsf2542345.jpg




