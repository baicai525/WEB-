/*
var str1='tedu';//字面量
//包装为对象
var str2=new String('tedu');
//String普通函数
//可以将任意数据转为字符串
var str3=String(true);
//console.log(str3,typeof str3);
var arr=[5,8,19];
//对象下的方法
console.log( arr.toString() );
//函数
console.log( String(arr) );

//console.log(str1, typeof str1);
//console.log(str2, typeof str2);
//console.log( str1+'web' );
//console.log( str2+'web' );
*/

//console.log('ran\'s playing dangang');
//console.log('yes \no');
//console.log('a\tb');//\t  tab键 换行
console.log('C:\\Users\\web');
// C:/Users/web