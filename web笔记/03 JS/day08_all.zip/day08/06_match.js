var str='Ran有一个非洲的女朋友，ran发明了煎饼机，RAN家住北京市，ran曾在日本工作8年';
//查找ran
//console.log( str.search('ran') );
// ignore  忽略大小写
//console.log( str.search(/ran/i) );
//查找所有匹配的
//global  全局查找
//console.log( str.match(/ran/ig) );
//查找并替换
console.log( str.replace(/ran/ig,'然哥') );