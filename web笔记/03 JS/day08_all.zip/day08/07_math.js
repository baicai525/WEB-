//0~1 包含0，不包含1 >=0  <1
/*
console.log( Math.random() );
console.log( Math.random() );
console.log( Math.random() );
*/
//0~9之间的随机数
//0~1 * 10   0~9.xxxx
//parseInt
var n=parseInt( Math.random()*10 );
console.log(n);