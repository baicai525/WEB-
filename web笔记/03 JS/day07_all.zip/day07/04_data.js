/*
//原始类型数据的存储
var a=1;
//把a的值拷贝一份，然后赋给b，a和b都是独立的两个数据
var b=a;
a=3;
console.log(b);
*/

//引用类型数据存储
var ran={
  color:'荧光绿',
  size:'XXXL'
}
var dong=ran;
dong.size='XXXXXL';
//console.log(ran);
ran.color='红色';
console.log(dong);
console.log(ran);
//销毁对象
ran=null;
dong=null;

//console.log(typeof null);

