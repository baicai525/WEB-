var person={
  name:'山田一然',
  sex:'男',
  //添加方法
  play:function(){
	//目前：this指代当前所在的对象
    console.log(this.name+'正在玩单杠');
  },
  play2:function(){
    console.log(this.name+'正在游泳');
  }
}
//调用对象下的方法
//person.play();
//person.play2();

//练习：创建一个圆对象，包含的属性有半径和圆周率，添加计算面积和周长的两个方法，最后调用两个方法
var circle={
  r:5,
  pi:3.14,
  getArea:function(){
    console.log( this.pi*this.r*this.r );
  },
  getLength:function(){
    console.log( 2*this.pi*this.r );
  }
}
console.log( circle );
circle.getArea();
circle.getLength();




