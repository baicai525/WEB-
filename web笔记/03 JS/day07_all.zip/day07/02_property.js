var person={
  name:'然哥',
  sex:'男',
  age:44
}
//和undefined比较
//true 不存在  false 存在
//console.log( person.age===undefined );
//true  存在  false 不存在
//console.log( person.hasOwnProperty('salary') );
//true  存在  false 不存在
//console.log( 'sex' in person );


//练习：声明变量保存一个商品的对象，包含有商品的编号，标题，价格；如果价格存在，将价格打八折；如果产地属性不存在，添加产地为中国。
var laptop={
  lid:1,
  title:'小米Air',
  price:5000
}
//如果存在
if( laptop.hasOwnProperty('price') ){
  laptop.price*=0.8;
}
//如果不存在
//if( laptop.madeIn===undefined ){
//  laptop.madeIn='中国';
//}
//如果不存在
if( !laptop.hasOwnProperty('madeIn') ){
  laptop.madeIn='china';
}

console.log( laptop );






