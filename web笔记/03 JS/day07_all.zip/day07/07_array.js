//索引数组：以0及以上的整数作为下标
//关联数组：以字符串作为下标
var arr=[12000];
arr['name']='ran';
arr['sex']='男';
arr.age=44;
//console.log(arr);
//console.log(arr.length);

//练习：创建数组，包含有多个员工（员工的属性包含有编号，姓名）
var emp=[
  {
	eid:1,
	ename:'ran'
  },
  {
    eid:2,
	ename:'dong'
  }
];
//console.log(emp);
//练习：创建一个学生对象，包含有学号，姓名，选修课列表(数组)
var student={
  sid:1,
  name:'然哥',
  course:['机械工程','食品工程']
}
console.log(student);

