//创建数组保存一组学生的数据
//字面量
var student=['陈子豪','颜涛','邓威',20,true];
//console.log(student,typeof student);
//创建数组，包含多个成绩
var score=[70,82,93,69];
//console.log(score);
//练习：创建数组，包含有多个城市的名称；
var city=['长沙','成都','哈尔滨','郑州'];
//console.log(city);
//元素的访问
//下标：JS给每个元素设置的编号，从0开始
//console.log( city[0],city[2],city[4] );
//添加
city[4]='瓦坎达';
city[6]='广州';
//修改
city[2]='长春';

//console.log(city);

//练习：创建数组，包含有多个汽车名称，添加多个，修改其中1个，打印数组。
var car=['五菱宏光','劳斯莱斯','特斯拉'];
car[0]='长安';
car[3]='雷诺';
car[4]='奇瑞';
car[car.length]='比亚迪';
car[car.length]='长城';
//属性：获取当前数组元素的个数（数组长度）
//console.log(car.length);
//console.log(car);

//练习：创建一个空数组，使用数组的长度添加若干个商品的名称
var laptop=[];
laptop[ laptop.length ]='小米Air';
laptop[ laptop.length ]='ThinkPadE470';
laptop[ laptop.length ]='荣耀';
console.log(laptop);

