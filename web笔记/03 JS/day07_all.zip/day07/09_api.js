//将数组转为字符串
var arr=[80,93,68];
//console.log(arr);
//只要是不同类型的对象，即使方法名字相同，也不是同一个方法
//console.log(arr.toString());
console.log( arr.join('-') );
//数值型 toString
//数组   toString




