//var score=[90,87,72,95];
//遍历
//for-in
/*
for(var k in score){
  //k 代表下标
  //score[k]  代表每个元素
  //console.log(k,score[k]);
  //打印出80分以上的
  if(score[k]>80){
    console.log(score[k])
  }
}

//练习：使用for循环遍历一组成绩，计算出平均成绩
var score=[90,87,72,95,65,81,61];
for(var i=0,sum=0;i<score.length;i++){
  //i 代表下标
  //console.log(i,score[i]);
  //计算总成绩
  sum+=score[i];
}
console.log(sum/score.length);

//练习：声明变量保存一组姓名，要求将所有姓名为'然哥'的元素，重新赋值为'ran'
var arr=['然哥','然然','阿然','小然','然哥'];
//找到每一个姓名
for(var i=0;i<arr.length;i++){
  //console.log(i,arr[i]);
  //判断是否为然哥
  if(arr[i]==='然哥'){
    arr[i]='ran';
  }
}
console.log(arr);
*/
//练习：声明变量保存一组数字，遍历数组找到最大值。
//23  45  9  78  6
//一组数字
var arr=[23,45,9,78,6];
//声明变量用于保存最大值，默认第1个数字为最大值
var max=arr[0];
//遍历数组，用max和每个元素比较
//i=1表示从第2个开始比较
for(var i=1;i<arr.length;i++){
  //每个元素 arr[i]
  //如果max小于任何一个元素，则把该元素赋给max
  if(max<arr[i]){
    max=arr[i];
  }
}
console.log(max);








