var student={
  s1:71,
  s2:59,
  s3:80,
  s4:63
}
//遍历
var sum=0;//用于记录总分
var i=0;//用于记录属性的个数
for(var k in student){
  //console.log(k,student[k]);
  //把每一个成绩加到sum中
  sum+=student[k];
  //每遍历得到一个成绩，让属性的数量加1
  i++;
}
console.log(sum/i);
