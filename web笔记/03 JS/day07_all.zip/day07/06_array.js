//内置构造函数       
var arr=new Array('头条','美团','拼多多');
//console.log(arr);

//创建数组，并初始化数组的元素个数
var arr2=new Array(3);
arr2[0]='邓威';
arr2[1]='刘俊逸';
arr2[2]='刘波';
arr2[3]='王梦超';
//console.log(arr2);

//练习：创建数组，包含有多个国家名称
//创建数组，初始化长度为5，添加篮球场上的5个位置。
var country=new Array('瓦坎达','印度','日本');
//console.log(country);
var ball=new Array(5);
ball[0]='中锋';
ball[1]='大前锋';
ball[2]='小前锋';
ball[3]='得分后卫';
ball[4]='控球后卫';
console.log(ball);
