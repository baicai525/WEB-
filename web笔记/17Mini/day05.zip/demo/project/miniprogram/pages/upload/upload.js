// pages/upload/upload.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imagePaths: []
  },
  //预览图片
  previewImage(event){
    let path = event.target.dataset.path;
      wx.previewImage({
        urls: this.data.imagePaths ,
        current:path      
      })
  },
  // 上传图片
  uploadImage() {
    // 依次将图片上传到云存储空间
    let imagePaths = this.data.imagePaths;
    imagePaths.forEach(item => {
      //获取文件扩展名 --> 如 jpg
      let extension = item.substr(item.lastIndexOf('.') + 1).toLowerCase();
      //生成唯一的主文件名称 --> 如 1000300
      let mainname = '' + Date.now() + Math.ceil(Math.random() * 999999);
      //将主文件名与扩展名拼接在一起形成新的文件全称 1000300.jpg
      let filename = mainname + '.' + extension;      
      /////////////////////////////////
      wx.cloud.uploadFile({
        filePath: item,
        cloudPath: 'webtn2007/' + filename,
        //cloudPath: `webtn2007/${filename}`,
        config: { 
          env: 'tedu-wuhua-web'
        },
        success:res=>{
            console.log(res);
        }
      });
      /////////////////////////////////
    });

  },
  // 弹出选取图片的对话框 
  chooseImage() {
    wx.chooseImage({
      //最多选取的图片数量
      count: 9,
      //album,相册;camera,相机
      sourceType: ['album', 'camera'],
      success: res => {
        this.setData({
          imagePaths: res.tempFilePaths
        })
        console.log(res);
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})