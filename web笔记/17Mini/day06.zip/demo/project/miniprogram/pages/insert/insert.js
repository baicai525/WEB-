// pages/insert/insert.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  // 查找所有记录
  selectAll() {
    // 获取数据库对象
    let db = wx.cloud.database({
      env: 'tedu-wuhua-web'
    });
    // 获取集合对象的引用,因为只有获取到集合对象才能针对该集合进行增删改查的操作
    let coll = db.collection('test');
    // 调用get()方法以查找集合的数据 -- 想像成  SELECT * FROM ...
    coll.get({
      success:res=>{
          console.log(res);
      }
    })
  },
  // 插入记录
  insert() {
    //获取数据库对象 --- 想像成  USE 数据库名称
    let db = wx.cloud.database({
      env: 'tedu-wuhua-web'
    });
    //获取对于指定集合的引用,因为只有获取到集合的引用，才可以在该集合中进行增、删、改、查等操作
    let coll = db.collection('test');
    //调用集合的add()方法插入记录 -- add()方法可以想像成 INSERT 语句
    coll.add({
      //插入的数据
      data: {
        productName: "Apple iPhone 11 (A2223) 128GB 黑色 移动联通电信4G手机 双卡双待",
        salePrice: 4999,
        comments: [
          {
            username: "苏幕遮陆",
            content: "间比以前几款好多了，整体来说是个不错的选择！手感特别好，颜色很喜欢，大小很合适",
            created_at: new Date()
          },
          {
            username: "力哥",
            content: "下了几个app运行的还比较顺畅，暂无卡顿，待机时间比以前几款好多了",
            created_at: new Date()
          }
        ]
      },
      success: res => {
        console.log(res);
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})