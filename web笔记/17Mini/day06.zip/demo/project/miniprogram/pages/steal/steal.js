// pages/steal/steal.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      epub:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //只要将要写入的数据准备完毕
    let array = [];
    wx.request({
      url:'https://api.zhuishushenqi.com/ranking/gender',
      method:'get',
      success:res=>{
        let data = res.data.epub;
        data.forEach(item=>{
           let object = {};
           wx.request({
             url:'https://api.zhuishushenqi.com/ranking/' + item._id,
             method:'GET',
             success:res=>{
                object.title = item.title;
                object.books = res.data.ranking.books;
                array.push(object);
                this.setData({
                  epub:array
                });
                console.log(this.data.epub);
             }
           })
        });
        
      }
    })
  },

  writeData(){
    let epub = this.data.epub;
    console.log(epub);
    let db = wx.cloud.database({
      env:'tedu-wuhua-web'
    });
    // 获取分类集合
    let categoryColl = db.collection('category');
    // 获取图书集合
    let booksColl = db.collection('books');
    // 遍历在分类集合中进行插入操作
    epub.forEach(item=>{
      categoryColl.add({
          data:{
            categoryName:item.title
          },
          success:res=>{
            let categoryId = res._id;
            console.log(categoryId);
             item.books.forEach(book=>{
                booksColl.add({
                  data:{
                    title:book.title,
                    categoryId:categoryId,
                    author:book.author,
                    majorCate:book.majorCate,
                    shortIntro:book.shortIntro,
                    cover:'http://statics.zhuishushenqi.com' + book.cover
                  }
                })
             });
          }
      })
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})