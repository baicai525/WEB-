// pages/get/get.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  specialField() {
    let db = wx.cloud.database({
      env: 'tedu-wuhua-web'
    });
    let coll = db.collection('test');
    //SELECT 字段,字段 FROM ....
    coll.field({
      _openid:false,
      created_at:false,
      "userInfo.age":false
      // userInfo:{
      //   age:false
      // }
    }).get({
      success:res=>{
        console.log(res);
      }
    })
  },

  specialWhere(){
    let db = wx.cloud.database({
      env: 'tedu-wuhua-web'
    });
    let coll = db.collection('test');
    /////////////////////////////////
    //想像成  SELECT * FROM ... WHERE ...
    coll.where({
      // userInfo:{
      //   age:db.command.lt(23)
      // }
      "userInfo.age":db.command.eq(20)
    }).get({
      success:res=>{
        console.log(res);
      }
    })
    ////////////////////////////////
  },
  specialOrder(){
    let db = wx.cloud.database({
      env: 'tedu-wuhua-web'
    });
    let coll = db.collection('test');
    //想像成 SELECT ... FROM ... ORDER BY xx,DESC
    coll.orderBy("userInfo.age","desc").get({
      success:res=>{
          console.log(res);
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})