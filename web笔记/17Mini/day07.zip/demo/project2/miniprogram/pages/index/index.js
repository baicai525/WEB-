//index.js
const app = getApp()

Page({
  data: {
    epub:[]
  },
  onLoad: function() {      
      let epub = this.data.epub;    
      // 获取数据库实例
      let db = wx.cloud.database({
        env:'tedu-wuhua-web'
      });
      // 获取集合的引用
      let categoryColl = db.collection('category');
      let booksColl = db.collection('books');
      // 获取所有的分类记录
      categoryColl.field({
        _openid:false
      }).get({
        success:res=>{                    
          ////////////////////////////////////////
          // 获取所有分类所形成的对象数组
          let categoryArray = res.data;
          // 循环分类所形成的对象数组,依次获取到其包含的图书数据
          categoryArray.forEach(category=>{
            booksColl.field({
              _openid:false,
              shortIntro:false,
              categoryId:false
            }).where({
              categoryId:db.command.eq(category._id)
            }).get({
              success:res=>{
                let object = {};
                //对象的标题是分类名称
                object.title = category.categoryName;
                //对象的books是查询的结果
                object.books = res.data;
                epub.push(object);
                this.setData({
                  epub:epub
                });
                //console.log(this.data.epub);
              }
            })
          });
         ////////////////////////////////////////////
        }
      });
  }
})
