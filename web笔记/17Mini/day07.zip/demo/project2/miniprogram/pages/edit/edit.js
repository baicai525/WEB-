const db = wx.cloud.database({
  env: 'tedu-wuhua-web'
});
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:{},
    title:'',
    author:'',
    id:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let id = options.id;
    // console.log('这是初始化时得到的id:' + id);
    this.setData({
      id:id
    });
    let coll = db.collection('books');
    coll.doc(id).get({
      success:res=>{
        console.log(res.data);
        this.setData({
          info:res.data,
          //图书名称
          title:res.data.title,
          //图书作者
          author:res.data.author
        });
      }
    })
  },

  titleInputEvent(event){
    let title = event.detail.value;
    this.setData({
      title:title
    });
    //console.log(title);
  },
  authorInputEvent(event){
    let author = event.detail.value;
    this.setData({
      author:author
    });
  },

  modifyEvent(){
    let id = this.data.id;
    // console.log('这是确认修改时的ID:' + id);    
    let title = this.data.title;
    let author = this.data.author;
    //console.log(title,author);
    
    //获取集合
    let coll = db.collection('books');
    coll.doc(id).update({
      data:{
        title:title,
        author:author
      }
    });
    wx.redirectTo({
      url: '/pages/lists/lists'
    })
    
    //console.log('编辑成功');
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})