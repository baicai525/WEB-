const db = wx.cloud.database({
  env: 'tedu-wuhua-web'
});
Page({

  /**
   * 页面的初始数据
   */
  data: {
    books:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let coll = db.collection('books');
    coll.limit(5).get({
      success:res=>{
        this.setData({
          books:res.data
        })
      }
    })
  },

  editEvent(event){
    let id = event.target.dataset.id;
    wx.navigateTo({
      url: '/pages/edit/edit?id=' + id
    });
  },
  removeEvent(event){
    let books = this.data.books;
    let id = event.target.dataset.id;
    let index = event.target.dataset.index;
    let coll = db.collection('books');
    wx.showModal({
      title:'删除确认',
      content:'您确认要删除吗?',
      success:res=>{
        if(res.confirm){
          coll.doc(id).remove({
            success:res=>{
              books.splice(index,1);
              this.setData({
                books:books
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})