//获取小程序实例
const app = getApp();
const db = wx.cloud.database({
  env:'tedu-wuhua-web'
});
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:{},
    comments:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {    
    //获取URL地址栏传递的ID参数
    let id = options.id;
    // 获取集合的引用
    let coll = db.collection('books');
    // 以获取的ID为条件在books集合中进行查找
    // coll.where({
    //   _id:db.command.eq(id)
    // }).get({
    //   success:res=>{
    //     //console.log(res);
    //   }
    // })
    // 以获取的ID为条件在books集合中进行查找
    // coll.doc().field()....
    coll.doc(id).field({
      _openid:false,
      categoryId:false
    }).get({
      success:res=>{
        //console.log(res.data);        
        this.setData({
          info:res.data
        });
        // 设置标题栏文本
        wx.setNavigationBarTitle({
          title:app.globalData.siteName + res.data.title
        });
        // 设置标题栏颜色
        wx.setNavigationBarColor({
            frontColor:'#ffffff',
            backgroundColor:'#990000'
        });
      },
      fail(){
         console.log('Not Found');
      }
    }) ;
    ////////////////////////////////
    // 获取图书的评论信息
    let commentsColl = db.collection('comments');
    // 以图书ID为条件进行评论信息的查找
    commentsColl.where({
      bookId:db.command.eq(id)
    }).skip(0).limit(2).get({
      success:res=>{
        this.setData({
          comments:res.data
        })
        //console.log(res);
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})