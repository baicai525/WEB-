// pages/page02/page02.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      console.log(options);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  //先触发onShow()，此时页面中的data数据还没有初始化完成,但已经可以显示静态的WXML标签了，这样做的目的是：为了防止用户长时间的面对空白页面
  onShow: function () {
    console.log('页面显示 -- page.onshow...');
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  //onReady,代表静态已经显示成功显示了，而且逻辑层的数据也已经发送给了视图层，可以与视图层进行交互了
  onReady: function () {
    console.log('ready...');
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log('页面隐藏 -- page.onHide...');
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})