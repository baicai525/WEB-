// pages/page06/page06.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      //存储出版类型
      epub:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url: 'https://api.zhuishushenqi.com/ranking/gender',
      method:'GET',
      success:res=>{
        console.log(res.data.epub);
        let data = res.data.epub; //[{_id:..,title:'xx'},{_id:..,title:'yy'},{},....]
        //数据的遍历
        data.forEach(item=>{
          let epub = this.data.epub;
          console.log(item._id +',' + item.title);
          //依次依当前的分类id为条件调用一个接口以获取数据
          ////////////////////////////////////////////
          //***************************************/*/
          // 创建空对象
          let object = {};
          wx.request({
              url:'https://api.zhuishushenqi.com/ranking/' + item._id,
              method:'GET',
              success:res=>{
                  //分类的标题
                  object.title = item.title;
                  //分类的图书信息
                  object.books = res.data.ranking.books;
                  //数组中添加成员
                  epub.push(object);
                  //现新this.data中的数据
                  this.setData({
                    epub:epub
                  });
                  console.group(item.title + '分类下包含的信息有:');
                  console.log(object);
                  console.log(res.data);
                  console.groupEnd();
              }
          })
          ////////////////////////////////////////////
        });

        this.setData({
         //epub:res.data.epub
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})