// pages/todo/todo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //存储待办事项列表
    todo:[],
    //存储输入的待办事项
    todoItem:''
  },
  //单击添加新事项按钮时调用方法
  addEvent(){
    //获取输入框变量的信息 -- 假设得到的是'DD'
    let todoItem = this.data.todoItem;
    if(todoItem.length == 0){
      wx.showToast({
        title: '项目禁止为空',
        image:"/images/error.png",
        mask:true,
        duration:2500
      });
    } else {
      // 先获取原始数组的数据 --> 假设得到的是 ['AA','BB','CC']
      let todo = this.data.todo;
      //在局部变量的未尾添加DD,结果就是 ['AA','BB','CC','DD']
      todo.push(todoItem);
      this.setData({
        todo:todo, //用新数组进行赋值操作,因为原来是['AA','BB','CC'],
                  //而现在变成了['AA','BB','CC','DD']
                  //在进行输出时视觉感觉起来只是新增了一个
        todoItem:''
      })
    }
  },
  //在在输入框输入过程中调用的方法
  inputEvent(event){
      //修改输入的待办事项变量
      this.setData({
        //删除输入字符串的前导和后续空格
        todoItem:event.detail.value.trim()
      })
      //console.log(event.detail.value);
  },
  // 单击删除按钮时调用的方法
  removeEvent(event){
    wx.showModal({
        title:"删除提示",
        content:"您确认要删除吗?",
        showCancel:true,
        confirmText:"确认",
        cancelText:"放弃",
        success:res=>{
          if(res.confirm){
            //获取自定义属性的值
            let id = event.target.dataset.id;
            //获取原始的待办事项列表
            let todo = this.data.todo;
            todo.splice(id,1);
            this.setData({
              todo:todo
            });
            //console.log('将要删除下标为' + id + '的待办事项了');
            //console.log('待办事项删除成功');
          }
        }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})