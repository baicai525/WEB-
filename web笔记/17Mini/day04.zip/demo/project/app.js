//app.js
App({
  //好比是软件安装成功后，在第一次启动时来完成的初始化配置工作
  onLaunch() {
    console.log('小程序初始化完成 -- onLaunch...');
  },
  //在配置工作完成后，软件才开始启动以显示welcome页面
  //只要在启动之后，用户切换到其他的应用时(如腾讯新闻)将自动调用onHide()回调
  //只要用户再次切换到小程序时，就再次触发onShow()回调
  onShow(){
    console.log('小程序启动或从后台切入到前台触发 -- onShow...');
  },
  onHide(){
    console.log('小程序从前台切入到后台时触发 -- onHide...');
  },
  globalData: {
    userInfo: null
  }
})