// pages/binding/binding.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //必须是可以转换为JSON类型的数据
    //string、number、boolean、array、object、null
    username:'Tom',
    age:23,
    salary:7895.15,
    sex:true,
    education:null,
    books:[
      {
        bookName:'XML完全探索',
        salePrice:98.6,
        //出版社ID
        //1代表中国青年出版社
        //2代表邮电出版社
        //3代表清华大学出版社
        //4代表电子工业出版社
        //5代表中国武警出版社
        publishingId:1
      },
      {
        bookName:'Node.js编程100例',
        salePrice:128,
        publishingId:3
      },
      {
        bookName:'jQuery源码分析',
        salePrice:58,
        publishingId:4
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})