#设置客户端连接服务器端的编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS xz;
#创建新的数据库，设置存储的编码
CREATE DATABASE xz CHARSET=UTF8;
#进入该数据库
USE xz;
#创建保存笔记本家族分类的表
CREATE TABLE family(
  fid INT PRIMARY KEY,
  fname VARCHAR(8) DEFAULT '未知'
);
#插入数据
INSERT INTO family VALUES
(10,'联想'),
(20,'戴尔'),
(30,'小米');
INSERT INTO family VALUES(40,'华为');
INSERT INTO family VALUES(50,NULL);
INSERT INTO family VALUES(60,NULL);
INSERT INTO family VALUES(70,DEFAULT);
INSERT INTO family(fid) VALUES(80);
#创建保存笔记本数据的表
CREATE TABLE laptop(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(64) UNIQUE NOT NULL,
  price DECIMAL(7,2) DEFAULT 3000,  #99999.99
  spec VARCHAR(32),
  detail VARCHAR(5000),
  shelfTime DATE,
  isOnsale BOOLEAN,
  familyId INT,
  #设置familyId为外键约束，取值范围到分类表family中的fid下去寻找，如果没有出现就会报错
  foreign key(familyId) references family(fid)
);
#插入数据
INSERT INTO laptop VALUES(1,'小米Air',3799,'旗舰版','详情1','2020-5-1',1,30);
INSERT INTO laptop VALUES(2,'ThinkpadE470','2899','入门版','详情2','2018-1-1',0,10);
INSERT INTO laptop VALUES(3,'灵越燃7000','4199','商务版','详情3','2019-12-1',1,20);
INSERT INTO laptop VALUES(4,'灵越燃8000','5199','商务版2','详情4','2018-12-1',0,20);
INSERT INTO laptop VALUES(5,'小新500',DEFAULT,DEFAULT,'详情5','2018-12-1',0,10);
INSERT INTO laptop(lid,title) VALUES(56,'小米Pro');
INSERT INTO laptop(lid,title) VALUES(NULL,'小米Pro2');
INSERT INTO laptop(lid,title) VALUES(NULL,'小米Pro3');