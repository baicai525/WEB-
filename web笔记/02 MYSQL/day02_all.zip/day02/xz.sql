#设置客户端连接服务器端的编码为UTF-8
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS xz;
#创建新的数据库,设置存储编码为UTF-8
CREATE DATABASE xz CHARSET=UTF8;
#进入该数据库
USE xz;
#创建保存数据的表
CREATE TABLE user(
  uid INT,
  uname VARCHAR(16),
  upwd VARCHAR(32),
  email VARCHAR(32),
  phone VARCHAR(11),
  userName VARCHAR(8),
  regTime VARCHAR(10),   #2020-08-03
  isOnline VARCHAR(1)  #y/n
);
#插入数据
INSERT INTO user VALUES('1','ran','123456','ran@163.com','18112345678','然哥','2019-12-20','y');
INSERT INTO user VALUES('2','dong','888888','dong@qq.com','13999999999','李东','2020-1-3','n');
INSERT INTO user VALUES('3','hua','666666','hua@tedu.cn','15812345678','钟华','2018-5-5','n');
#删除数据
DELETE FROM user WHERE uid='2';
#修改数据
UPDATE user SET phone='18500000000',isOnline='y' WHERE uid='3';
#查询数据
SELECT * FROM user;
