#设置客户端连接服务器端的编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS qq;
#创建数据库，设置存储的编码
CREATE DATABASE qq CHARSET=UTF8;
#进入该数据库
USE qq;
#创建保存新闻数据的表
CREATE TABLE news(
  nid INT,
  title VARCHAR(32),
  detail VARCHAR(5000),
  ctime VARCHAR(10),
  origin VARCHAR(16)
);
#插入数据
INSERT INTO news VALUES('1','然哥于今晨购得一绿色假发','详情1','2020-8-1','达内日报');
INSERT INTO news VALUES('2','然哥与印度女友在西单商场被偷拍','详情2','2020-8-3','娱乐日报');
INSERT INTO news VALUES('3','特朗普今晨死于枪杀','详情3','2020-8-3','纽约时报');
#修改数据
UPDATE news SET ctime='2020-8-2' WHERE nid='2';
#删除数据
DELETE FROM news WHERE nid='3';
