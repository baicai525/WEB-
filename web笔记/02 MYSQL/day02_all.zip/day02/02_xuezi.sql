#设置客户端连接服务器端编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS xuezi;
#创建新的数据库，设置存储编码
CREATE DATABASE xuezi CHARSET=UTF8;
#进入该数据库
USE xuezi;
#创建保存商品数据的表
CREATE TABLE laptop(
  lid INT PRIMARY KEY,
  title VARCHAR(64),
  price DECIMAL(7,2) NOT NULL,  #99999.99
  stockCount SMALLINT,
  shelfTime DATE,
  isIndex BOOLEAN
);
#插入数据
INSERT INTO laptop VALUES('4','小米Air','3199','100','2020-8-1',true);
INSERT INTO laptop VALUES('2','外星人','56000','12','2020-1-1',false);

INSERT INTO laptop VALUES(1,'ThinkpadE470',3199,6,'2016-10-1',NULL);

INSERT INTO laptop VALUES('3','戴尔燃7000','4199','200','2019-10-1','130');