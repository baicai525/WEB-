const express=require('express');
//引入用户路由器
const userRouter=require('./user.js');
//创建web服务器
const app=express();
//设置端口
app.listen(8080);

//挂载路由器到web服务器下，添加前缀
//参数1：添加的前缀 /user  访问形式  /user/list
//参数2：要挂载的路由器
app.use('/user',userRouter);