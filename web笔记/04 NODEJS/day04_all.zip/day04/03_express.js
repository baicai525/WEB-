const express=require('express');
//引入查询字符串模块
const querystring=require('querystring');
//创建web服务器
const app=express();
//设置端口
app.listen(8080);

//响应搜索网页的路由
//get  /search
app.get('/search',(req,res)=>{
  res.sendFile(__dirname+'/search.html');
});
//根据表单提交请求创建对应的路由
//get  /mysearch
app.get('/mysearch',(req,res)=>{
  //req 请求对象
  //console.log(req.method,req.url);
  //直接获取到传递的数据，格式为对象
  console.log( req.query );
  res.send('这是商品列表：'+req.query.keyword);
});

//路由，获取登录的网页
//get  /login
app.get('/login',(req,res)=>{
  res.sendFile(__dirname+'/login.html');
});
//根据表单的请求创建对应的路由
//post  /mylogin
app.post('/mylogin',(req,res)=>{
  //获取post传递的数据
  //以流的形式传递，通过事件
  //一旦有数据流入，自动调用回调函数
  req.on('data',(chunk)=>{
    //将分段的数据放入到参数chunk，格式为buffer
	//console.log(chunk);
	//转字符串为查询字符串
	let str=String(chunk);
	//console.log(str);
	//解析为对象
	let obj=querystring.parse(str);
	console.log(obj);
    res.send('登录成功，欢迎：'+obj.uname);
  })
});
//路由：查看包的使用详情
//get  /package
app.get('/package/:pname',(req,res)=>{
  //获取路由传参的数据,格式为对象
  console.log(req.params);
  res.send('这是包的使用详情');
});

// 练习：创建添加到购物车的路由(get  /shopping)，使用路由传参传递商品的编号lid和数量num，在路由获取数据
app.get('/shopping/:lid/:num',(req,res)=>{
  console.log(req.params);
  res.send('购物车添加成功');
});





