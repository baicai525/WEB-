const http=require('http');
const fs=require('fs');
//创建web服务器
const app=http.createServer();
//给服务器设置端口
app.listen(8080);

//给服务器添加事件，根据请求作出响应
app.on('request',(req,res)=>{
  if(req.url==='/list') {
    res.write('this is product list');
  }else if(req.url==='/index'){
    //设置响应的内容类型为html，编码为utf-8
	res.writeHead(200,{
	  'Content-Type':'text/html;charset=utf-8'
	});
    res.write('<h2>这是首页</h2>');
  }else if(req.url==='/'){
    //响应文件
	//先读取，格式为buffer
	let data=fs.readFileSync('./1.html');
	//把读取到的数据作为响应的内容,将buffer数据隐式转换为了字符串
    res.write(data);
  }else if(req.url==='/study'){
    res.writeHead(302,{
	  Location:'http://www.tmooc.cn'
	});
  }else{
    res.writeHead(404);
	res.write('Not Found');
  }
  //无论响应什么内容，最后再结束并发送
  res.end();
});
