//引入express包
const express=require('express');
//console.log(express);
//创建web服务器
const app=express();
//设置端口
app.listen(8080);

//处理商品列表的路由
//请求的URL:/list,请求的方法:get
//通过回调函数作出响应
app.get('/list',(req,res)=>{
  //req 请求的对象
  //res 响应的对象
  //设置响应的内容并发送
  res.send('这是商品列表');
});

//练习：创建首页的路由（/index， get），响应 <h2>这是首页</h2>
app.get('/index',(req,res)=>{
  res.send('<h2>这是首页</h2>');
});
//请求的URL: /  请求的方法: get ，响应文件1.html
app.get('/',(req,res)=>{
  //响应文件
  res.sendFile(__dirname+'/1.html');
});
//当前模块的绝对目录
//console.log(__dirname);

//商品详情路由
//请求方法: get 请求URL: /detail
app.get('/detail',(req,res)=>{
  res.sendFile(__dirname+'/detail.html');
});
//跳转
//请求的方法: get 请求的URL: /study
app.get('/study',(req,res)=>{
  res.redirect('http://www.tmooc.cn');
});







