var a=1;
function fn(){
  return 2;
}
//查看a和fn是否为全局
//console.log( global.a );
console.log( global.fn() )