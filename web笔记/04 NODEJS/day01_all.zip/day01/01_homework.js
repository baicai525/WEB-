//声明变量保存1~33之间所有数字
var arr=[];
for(var i=1;i<=33;i++){
  //i代表所以整数
  //添加到数组arr中
  arr.push(i);
}
//console.log(arr);
//准备一个空数组，用于保存取到随机元素
var arr2=[];
//循环6次，随机取6个数字
for(var i=0;i<6;i++){
  //随机下标 0~32
  //0~1 * 33   0~32.x  向下取整  0~32
  var n=parseInt( Math.random() * arr.length );
  //console.log(n);
  //通过随机下标找到对应的元素 arr[n]
  //把找到的元素放入到准备好的新数组arr2中
  arr2.push( arr[n] );
  //每次获取到随机元素后，把该元素从数组中删除
  //splice(开始的下标,删除的数量)
  arr.splice(n,1);
}


//对获取到的随机进行从小到大的排序
arr2.sort( function(a,b){
  return a-b;
} );
//1~16之间随机取1个数字
//只需要产生一个随机整数，然后添加到数组arr2
//0~1  * 17  0~16.x  向上取整
//0~1  * 16  0~15.x  向下取整  0~15  + 1  1~16
var blue=parseInt( Math.random()*16 ) + 1;
arr2.push(blue);
console.log(arr2);

//console.log(arr.length);


