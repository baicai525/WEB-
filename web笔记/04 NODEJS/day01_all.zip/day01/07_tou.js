//引入07_yan.js
// ./同一级目录下
//引入模块得到的就是对方公开的内容
let obj=require('./07_yan.js');
console.log(obj);
//使用
console.log(obj.mya, obj.myfn());