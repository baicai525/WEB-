var a=1;
function fn(){
  return 2;
}
//JS全局对象 window

console.log( window.a );
console.log( window.fn() );
