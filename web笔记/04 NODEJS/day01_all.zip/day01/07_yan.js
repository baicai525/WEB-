//(function(){    
console.log('这是一个眼睛模块');
var a=1;
function fn(){
  return 2;
}
//公开的内容，称为导出的对象  
//如果要公开哪些内容，只需要往对象中添加即可
//module 当前的模块对象
//module.exports  当前模块导出的对象，公开的内容，默认是一个空对象
module.exports={
  money:'1个亿',
  gf:3,
  mya:a,
  myfn:fn
}

//})