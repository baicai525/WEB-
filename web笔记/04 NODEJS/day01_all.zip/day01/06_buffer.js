//创建buffer空间，存储数据
let buf=Buffer.alloc(6,'然哥');
console.log(buf);
//转为字符串
console.log( String(buf), buf.toString() );