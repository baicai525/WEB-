/*
console.log(1);//日志
console.info(2);//消息
console.warn(3);//警告
console.error(4);//错误
*/

console.time('ran');//开始计时
for(let i=1;i<=100000;i++){
}
console.timeEnd('ran');//结束计时

console.time('dong');
let i=1;
while(i<=100000){
  i++;
}
console.timeEnd('dong');

console.time('xin');
let j=1;
do{
  j++;
}while(j<=100000);
console.timeEnd('xin');