/*
//变量提升
//var a;
console.log(a);
//反复声明多一个变量
var a=1;
var a=3;

//let声明的变量不存在提升
//不允许在同一个作用域下反复声明同一个变量
let b=2;
b=4;
console.log(b);

//大括号，块级作用域
{
  var c=3;
  let d=4;
}
console.log(c);
console.log(d);

//练习：使用for循环计算1~100之间所有整数的和，并打印结果。
let sum=0;
for(let i=1;i<=100;i++){
  //console.log(i);
  sum+=i;
}
console.log(sum);


//2.箭头函数
let arr=[23,9,78,6,45];
//从小到大排序
//arr.sort( (a,b)=>{
//  return a-b;
//} );
//如果箭头函数的函数体中只有return形式的一样代码
arr.sort( (a,b)=>a-b );

console.log(arr);

//练习：使用匿名函数的方式创建函数，计算任意两个数字相加的和并返回结果，匿名函数使用箭头函数代替
let add=(a,b)=>a+b

console.log(add(2,3));


//3.模板字符串
let ename='然哥';
let phone='13112345678';
let email='ran@tedu.cn';
let salary=5000;
console.log(`
  姓名：${ename}
  电话：${phone}
  邮箱：${email}
  工资：${salary.toFixed(2)}
`);
*/
//练习：声明变量保存一个商品对象，包含有商品的编号，标题，价格，是否在售(1/0)；打印出以下效果
let laptop={
  lid:3,
  title:'小米Air',
  price:3199,
  isOnsale:0
}
console.log(`
  编号：${laptop.lid}
  标题：${laptop.title}
  价格：${laptop.price.toFixed(2)}
  是否在售：${laptop.isOnsale===1 ? '是' : '否'}
`);





