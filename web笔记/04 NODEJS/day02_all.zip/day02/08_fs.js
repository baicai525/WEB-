//引入文件系统模块
const fs=require('fs');
/*
//1.查看文件状态
let s=fs.statSync('./04');
//console.log(s);
//是否为目录
console.log( s.isDirectory() );
//是否为文件
console.log( s.isFile() );
*/
//2.创建目录
//fs.mkdirSync('./mydir');

//3.移除目录
//fs.rmdirSync('./mydir');

