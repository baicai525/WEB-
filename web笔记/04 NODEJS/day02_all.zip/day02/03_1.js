//引入同一级目录下的03_2目录模块
let obj=require('./03_2');
console.log(obj);
//调用导出的函数
console.log( obj.add(2,3) );