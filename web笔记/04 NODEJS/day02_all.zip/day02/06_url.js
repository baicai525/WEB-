//引入URL模块
const url=require('url');
//引入查询字符串模块
const querystring=require('querystring');
//console.log(url);
/*
let str='http://www.codeboy.com:9999/products.html?kw=dell';
//将URL解析为对象
let obj=url.parse(str);
console.log(obj.query, obj.pathname);
*/

let str2='https://www.tmooc.cn:443/web.html?cid=2007&cname=nodejs';
//把URL解析为对象
let obj2=url.parse(str2);
console.log(obj2.query);
//把查询字符串解析为对象
let obj3=querystring.parse(obj2.query);
console.log(obj3.cid, obj3.cname);