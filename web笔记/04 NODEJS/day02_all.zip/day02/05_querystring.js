//引入查询字符串模块
const querystring=require('querystring');
//console.log(querystring);

/*
//查询字符串
let str='kw=dell&enc=utf-8';
//将查询字符串解析为对象
let obj=querystring.parse(str);
console.log( obj.kw,obj.enc );
*/

let str2='lid=5&price=8000&count=10';
//解析为对象
let obj2=querystring.parse(str2);
console.log(obj2);

