
/*
//1.一次性定时器
//3000毫秒后，调用一次回调函数
//开启
let timer=setTimeout(()=>{
  console.log('boom！');
},3000);
//清除
clearTimeout(timer);


//2.周期性定时器
//开启
//声明变量，用于记录次数
let i=0;
let timer=setInterval( ()=>{
  console.log('boom');
  //每打印1次加1
  i++;
  //当i为3的时候，清除定时器
  if(i===3){
    clearInterval(timer);
  }
},3000 );
//清除
//clearInterval(timer);
*/

//3.立即执行的定时器
console.log(2);
setImmediate( ()=>{
  console.log(1);
} );
process.nextTick( ()=>{
  console.log(4);
} );
console.log(3);



