//计算任意两个数字相加的和，返回结果
function add(a,b){
  return a+b;
}
//导出函数
module.exports={
  add:add
}