//引入circle.js模块
let obj=require('./circle.js');
//console.log(obj);
//console.log( obj.getLength(5).toFixed(2) );
//console.log( obj.getArea(5).toFixed(2) );

//绝对目录
console.log(__dirname);//dir->directory  目录
//绝对目录+模块名称
console.log(__filename);//file  文件

