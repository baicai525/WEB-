//计算周长
function getLength(r){
  return 2*Math.PI*r;
}
//计算面积
function getArea(r){
  return Math.PI*Math.pow(r,2);
}
//导出以上两个函数，外部才能使用
//往导出对象中添加要导出的函数
/*
module.exports={
  getLength: getLength,
  getArea: getArea
}
*/
let circle={
  getLength: getLength,
  getArea: getArea,
  a:1,
  b:2
}
//如果已经有一个对象，把它导出，直接赋给module.exports
module.exports=circle;