//引入fs模块
const fs=require('fs');
//3秒钟以后执行
setTimeout( ()=>{
  //创建1~10,10个目录
  for(let i=1;i<=10;i++){
    //console.log(i);
	//i作为目录名称
	// ./2
    fs.mkdirSync('./'+i);
  }
  console.log('创建完成');
  //删除创建的10个目录
  //5秒后删除
  setTimeout( ()=>{
	 //循环10次删除
     for(let i=1;i<=10;i++){
	   fs.rmdirSync('./'+i);
	 }
  },5000 );
},3000 );
//console.log('准备删除');