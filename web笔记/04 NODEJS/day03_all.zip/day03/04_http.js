//引入http模块
const http=require('http');
//创建web服务器
const app=http.createServer();
//设置端口
app.listen(8080);

//通过IP或者域名访问web服务器
//http://127.0.0.1:8080
//http://localhost:8080

//当浏览器发出请求，服务器端做出相应
//事件：当浏览器请求，自动执行回调函数，通过回调函数响应
app.on('request',(req,res)=>{
  //req 请求的对象
  //req.url  获取请求的URL
  //req.method  获取请求的方法
  console.log(req.url, req.method);
  //res 响应的对象
  //参数1：设置响应状态码
  //参数2：可选的，设置响应的头信息
  //res.writeHead(302,{
  //  Location:'http://www.tmooc.cn'
  //});
  //设置响应的内容
  res.write('这是你的jianbing');
  //结束并发送响应
  res.end();
});





