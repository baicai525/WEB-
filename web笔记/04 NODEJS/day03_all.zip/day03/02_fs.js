const fs=require('fs');
/*
//1.查看文件的状态
//同步
//let s=fs.statSync('./01_homework.js');
//console.log(s);
//异步
//这个操作就出现了单独的线程执行，把执行的结果以回调函数的形式返回，并放入到事件队列
fs.stat('./01_homework.js', (err,s)=>{  
  //err参数1: 放可能产生的错误
  //s 参数2: 读取到的文件的状态对象
  if(err){
    throw err;
  }
  console.log(s);
});
*/
//2.读取目录
//异步
/*
fs.readdir('./mydir',(err,result)=>{
  if(err) throw err;
  //result 读取到的结果
  console.log(result);
});
//同步
let result=fs.readdirSync('./mydir');
console.log(result);
*/
/*
//使用同步和异步方法创建目录 mydir1  mydir2
//mkdirSync   mkdir
//fs.mkdirSync('./mydir1');
fs.mkdir('./mydir2',(err)=>{
  if(err) throw err;
});

//3.写入文件
fs.writeFile('./1.txt','ran',(err)=>{
  if(err) throw err;
  console.log('创建成功');
});

//同步写入
fs.writeFileSync('./2.txt','ran');

//4.追加写入
fs.appendFile('./3.txt','ran\n',(err)=>{
  if(err) throw err;
  console.log('写入成功');
});

//练习：声明变量保存一组姓名（数组），遍历数组，得到每个数据，使用同步方法写入到文件stu.txt
var stu=['然哥','梁山','李汝钊','石卓然','梁哲'];
for(let i=0;i<stu.length;i++){
  //每个元素 stu[i]
  fs.appendFileSync('./stu.txt',stu[i]+'\n');
}


//5.读取文件
fs.readFile('./1.txt',(err,data)=>{
  if(err) throw err;
  //data 读取到的数据，格式为buffer，需要转字符串
  console.log( String(data) );
});

//使用同步方法读取2.txt
let data=fs.readFileSync('./2.txt');
console.log( data.toString() );

//6.删除文件
fs.unlink('./1.txt',(err)=>{
  if(err) throw err;
});

fs.unlinkSync('./2.txt');

//7.检测文件是否存在
let r=fs.existsSync('./mydir');
console.log(r);

//练习：如果文件3.txt存在，则删除该文件；如果目录a不存在，则创建该目录
if( fs.existsSync('./3.txt') ){
  fs.unlinkSync('./3.txt');
}
if( !fs.existsSync('./a') ){
  fs.mkdirSync('./a');
}

//8.拷贝文件
fs.copyFile('./stu.txt','./a/s.txt',(err)=>{
  if(err) throw err;
});
*/
//练习：拷贝02_fs.js到a目录下，名称为02_fs.txt， 使用同步方法
fs.copyFileSync('./02_fs.js','./a/02_fs.txt');


console.log('这是然哥的工作');


