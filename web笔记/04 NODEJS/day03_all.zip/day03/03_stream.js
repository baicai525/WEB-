//引入fs模块
const fs=require('fs');

/*
//创建可读取的流对象
let rs=fs.createReadStream('./1.exe');
//事件：一旦数据流入，自动触发回调函数
//on用于添加事件
//data 数据流入事件名称，固定的
//有数据流入，调用回调函数，将数据放入到参数chunk，就是获取的某一段数据
//声明变量用于统计段数
let i=0;
rs.on('data',(chunk)=>{
  //console.log(chunk);
  //每读取一段加1
  i++;
});
//事件：一旦读取结束，才会执行
//end 结束的事件名称，是固定的
rs.on('end',()=>{
  //结束后，打印查看有多少端
  console.log(i);
});
*/
//通过可读取的流和可写入的流完成文件的拷贝
let rs=fs.createReadStream('./1.exe');
let ws=fs.createWriteStream('./2.exe')
//把读取的流通过管道添加到写入流
rs.pipe(ws);





