const express=require('express');
const mysql=require('mysql');
const app=express();
app.listen(8080);
//托管静态资源到public目录
app.use( express.static('./public') );
//连接mysql数据库，创建连接池
const pool=mysql.createPool({
  host:'127.0.0.1',
  port:'3306',
  user:'root',
  password:'',
  database:'tedu',
  connectionLimit:'20'
});
//根据表单请求创建对应的路由
//get  /add
app.get('/add',(req,res)=>{
  //获取查询字符串传递的数据
  console.log(req.query);
  //将数据插入到数据表dept
  pool.query('INSERT INTO dept SET ?',[req.query],(err,result)=>{
    if(err) throw err;
	console.log(result);
	//只有数据插入后再响应
	res.send('部门添加成功');
  });
});


