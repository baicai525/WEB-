const express=require('express');
//创建web服务器
const app=express();
//设置端口
app.listen(8080);

//只能按照URL拦截
//拦截对 /list的请求
//参数1：要拦截的URL
//参数2：回调函数，一旦拦截到，自动调用这个函数
app.use('/list',(req,res,next)=>{
  //req res和路由中的是一样的
  //next 是一个函数，表示执行下一个中间件或者路由
  //获取以查询字符串传递的数据 
  console.log( req.query );
  //判断传递的用户名是否为管理员root
  //如果不是
  if(req.query.uname!=='root'){
    //响应
	res.send('请提供管理员账户');
  }else{
    //往后执行（下一个中间件或者路由）
	next();
  }
});
//用户列表路由
//get  /list
app.get('/list',(req,res)=>{
  res.send('这是所有用户的数据');
});

// http://127.0.0.1:8080/list?uname=abcd

//添加中间件，拦截添加购物车的请求
app.use('/shopping',(req,res,next)=>{
  //在中间件中获取数据，然后打折
  console.log(req.query);
  //对价格打九折
  req.query.price*=0.9;
  //往后执行
  next();
});
//添加购物车路由  get  /shopping
app.get('/shopping',(req,res)=>{
  //获取查询字符串传递的数据
  console.log(req.query);
  res.send('商品最终价格为：'+req.query.price);
});


