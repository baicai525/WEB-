//引入mysql模块
const mysql=require('mysql');
//创建连接对象
const c=mysql.createConnection({
  host:'127.0.0.1',
  port:'3306',
  user:'root',
  password:'',
  database:'tedu'  //连接成功后要进入的数据库
});
//测试连接
//c.connect();

//执行SQL命令
//参数1：SQL命令
//参数2：回调函数，用于获取结果
c.query('SELECT * FROM emp',(err,result)=>{
  //err 可能产生的错误
  if(err) throw err;
  //result  SQL命令执行的结果
  console.log(result);
});







