const express=require('express');
//const querystring=require('querystring');
//1.引入body-parser模块
const bodyParser=require('body-parser');
const app=express();
app.listen(8080);

//托管静态资源到public
app.use( express.static('./public') );
//2.将post请求的数据解析为对象
app.use( bodyParser.urlencoded({
  //是否使用扩展的查询字符串模块qs；false不使用，会使用官方提供的querystring，true使用
  extended:false
}) );
//根据表单的请求创建对应的路由
//post  /mylogin
app.post('/mylogin',(req,res)=>{
  //获取post请求的数据
  //3.获取数据，前提已经使用了body-parser中间件
  console.log(req.body);
  //通过事件
  /*
  req.on('data',(chunk)=>{
    //格式为buffer，需要转字符串，转后格式为查询字符串
	let str=String(chunk);
	//将查询字符串解析为对象
    let obj=querystring.parse(str);
	console.log(obj);
  })
  */
  res.send('登录成功');
});
