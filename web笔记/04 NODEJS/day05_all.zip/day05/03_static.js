const express=require('express');
const app=express();
app.listen(8080);

//托管静态资源到public目录
//浏览器端请求文件，自动到public目录寻找
app.use( express.static('./public') );
app.use( express.static('./files') );