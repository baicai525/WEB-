//引入mysql模块
const mysql=require('mysql');
//创建连接池对象
const pool=mysql.createPool({
  host:'127.0.0.1',
  port:'3306',
  user:'root',
  password:'',
  database:'tedu',
  connectionLimit:'20'
});
//执行SQL命令
/*
pool.query('SELECT * FROM emp WHERE eid=1',(err,result)=>{
  if(err) throw err;
  console.log(result);
})

//删除编号5的员工
pool.query('DELETE FROM emp WHERE eid=?',['15 or 1=1'],(err,result)=>{
  if(err) throw err;
  console.log(result);
});


//插入数据
pool.query('INSERT INTO emp VALUES(?,?,?,?,?,?)',[null,'然哥',0,'1977-5-29',50000,10],(err,result)=>{
  if(err) throw err;
  console.log(result);
});
*/

let ran={
  //eid:null,
  ename:'然然',
  salary:40000,
  deptId:20,
  sex:0
}
pool.query('INSERT INTO emp SET ?',[ran],(err,result)=>{
  if(err) throw err;
  console.log(result);
});





