<template>
  <div>
    <p><mt-button>默认按钮</mt-button></p>
    <p><mt-button type="primary">主要按钮</mt-button></p>
    <p><mt-button type="danger">危险按钮</mt-button></p>
    <p><mt-button size="small" type="primary">小的</mt-button></p>
    <p><mt-button size="normal" type="primary">标准的</mt-button></p>
    <p><mt-button size="large" type="primary">大的</mt-button></p>
    <p><mt-button type="primary" plain>镂空</mt-button></p>
    <p><mt-button type="primary" icon="back"></mt-button></p>
    <p><mt-button type="primary" icon="more"></mt-button></p>
  </div>
</template>