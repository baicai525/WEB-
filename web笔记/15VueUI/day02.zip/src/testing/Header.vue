<template>
  <div>
    <mt-header title="学前端,到学问">  
      <div slot="left">
          <mt-button icon="back"></mt-button>
      </div>         
      <div slot="right">注册登录</div>
    </mt-header>
  </div>
</template>