function getCompanyName(){
	return 'TEDU.CN';
}